def evaluate_math_expression(expression):
    try:
        result = eval(expression)
        return result
    except Exception as e:
        return "Invalid Expression. Please try again."
    
def define_custom_function():
    function_defination = input("Enter your custom function (e.g., def my_func(x): return x + 1): ")
    try:
        exec(function_defination)
        return "Function defined Successfully."
    except Exception as e:
        return "Error in function defination. Please try again."
    

def main():
    while True:
        user_input = input("Enter a mathematical expression (or type 'exit' to quit): ")
        if user_input.lower() == 'exit':
            print('Exit. Goodbye!')
            break
        elif user_input.lower().startswith("def "):
            print(define_custom_function())
        else:
            result = evaluate_math_expression(user_input)
            print(f"Result: {result}")
if __name__ == '__main__':
    main()