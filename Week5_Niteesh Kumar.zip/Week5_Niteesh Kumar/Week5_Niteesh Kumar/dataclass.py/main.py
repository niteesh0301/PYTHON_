import lab_dataclass as lb

book1 = lb.Book("1984"," George Orwell",1949,15.99)
print(book1)


book2 = lb.Book("To kill a Mockingbird", "Harper Lee", 1960)
print(book2)

book3 = lb.Book("The Great Gatsby", "F.Scott Fitzgerald", 1925, 20.0)
print(f"Original price: {book3.price}")
book3.apply_discount(0.1)
print(f"Discounted Price: {book3.price}")

library = lb.Library("City Library")
book4 = lb.Book("Moby Dick","Herman Melville",1851,12.0)
library.add_book(book4)
print(library.list_books())
library.remove_book(book4)
print(library.list_books())

book5 = lb.Book("War and Peace","Leo Tolstoy",1869,25.0)
book6 = lb.Book("Anna Karenina","Leo Tolstoy", 1877,22.0)
print(book5 > book6)


