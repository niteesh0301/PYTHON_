#Basic dataclass creation

from dataclasses import dataclass, field

@dataclass(order= True)

class Book:
    title: str
    author: str
    year: int
    price: float = field(default = 0.0) #Default Values and field parameters

#Adding methods
    def apply_discount(self, discount: float):
        self.price *= (1 - discount)

@dataclass
class Library:
    name: str
    books: list = field(default_factory=list)

    def add_book(self,book:Book):
        self.books.append(book)

    def remove_book(self,book:Book):
        self.books.remove(book)

    def list_books(self):
        return self.books
    

    