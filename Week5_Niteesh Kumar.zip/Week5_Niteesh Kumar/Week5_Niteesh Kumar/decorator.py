#Task 1: Create a Simple Decorator

def simple_decorator(func):
    def wrapper():
        print("*****Before the function call*****")
        result = func("😊",50,20)
        print("*****After the function call*****")
        return result
    return wrapper

@simple_decorator

def say_hello(emoji, x, y):
    print(f"Hello world! {emoji}")
    print(f"Add x and y = {x + y}")

say_hello()

#Task 2: Chaining Decorators

def decorator1(func):
    def wrappers(*args, **kwargs):
        print("Decorator 1 - Before the function call.")
        result = func(*args, **kwargs)
        print("Decorator 1 - After the function call.") 
        return result
    return wrappers

def decorator2(func):
    def wrappers(*args, **kwargs):
        print("Decorator 2 - Before the function call.")
        result = func(*args, **kwargs)
        print("Decorator 2 - After the function call.") 
        return result
    return wrappers

@decorator1
@decorator2

def multiply(a, b):
    print(f"Multiplying {a} and {b}")
    return a * b
result = multiply(5, 10)
print(f"Result: {result}")

@decorator2
def divide(a, b):
    print(f"Dividing {a} and {b}")
    return a / b
result2 = divide(5, 10)
print(f"Result: {result}")


#Task 3: Create a Simple Object Decorator
def add_method_decorator(cls):
    def new_method(self):
        print("This is a new method added by the decorator.")

    cls.new_method = new_method
    return cls

@add_method_decorator
class MyClass:
    def existing_method(self):
        print("This is an existing method.")

if __name__ == '__main__':
    obj = MyClass()
    obj.existing_method()
    obj.new_method()

