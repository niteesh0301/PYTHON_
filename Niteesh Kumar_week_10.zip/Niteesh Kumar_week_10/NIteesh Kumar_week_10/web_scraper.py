import requests
from bs4 import BeautifulSoup
 
url = "https://example.com"
response = requests.get(url)
 
if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')
 
    # Extract all <h1> and <h2> headings
    headings = soup.find_all(['h1', 'h2'])
    print("Headings found on the page:")
    for heading in headings:
        print(heading.text.strip())
 
    # Extract all hyperlinks
    links = soup.find_all('a')
    print("\nLinks found on the page:")
    for link in links:
        href = link.get('href')
        print(f"Text: {link.text.strip()}, URL: {href}")
else:
    print(f"Failed to retrieve the web page. Status code: {response.status_code}")
