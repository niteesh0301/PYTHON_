def my_factorial(n):
    if(n==0):
        return 1
    else:
       n  = n * my_factorial(n-1)
       return n
