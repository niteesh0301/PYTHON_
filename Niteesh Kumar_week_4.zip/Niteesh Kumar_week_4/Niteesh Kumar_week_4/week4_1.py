# Vehicle Parent Class
class Vehicle:
    def __init__(self, name, mileage):
        self.name = name
        self.mileage = mileage
    def display(self):
        print ("vehicle name:", self.name, "mileage:", self.mileage)        

vh = Vehicle("auto", 10000)
vh.display()

# Car Child Class
class Car(Vehicle):
    def carry_people(self):
        print("I can carry people")

a_car = Car("BMW",20000)
a_car.display()
a_car.carry_people()

# Truck Child Class
class Truck(Vehicle):
    def carry_things(self):
        print("I can carry things")

# Minivan Child Class
class Minivan(Car,Truck):
    def carry_people_things(self):
        print("I can carry people's things")

a_minivan = Minivan(name="U HAUL",mileage=40000)
a_minivan.display()
a_minivan.carry_things()

