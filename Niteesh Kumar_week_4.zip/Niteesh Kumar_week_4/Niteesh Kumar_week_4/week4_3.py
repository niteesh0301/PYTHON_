from my_module import my_factorial
result = my_factorial(1)
print(result)