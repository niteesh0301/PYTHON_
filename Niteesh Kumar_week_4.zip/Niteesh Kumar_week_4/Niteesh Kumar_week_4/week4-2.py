class BankAccount:
    def __init__(self,account_holder:str,balance:float=0.0):
        self.account_holder:str = account_holder
        self.balance:float = balance
        

    def deposit(self,amount):
        self.balance += amount
        return self.balance

    def withdraw(self,amount):
            self.balance -= amount
            return self.balance

    def display_balance(self):
        if(self.balance >= 0): 
            print(self.account_holder,"has", self.balance, "in the account.")
        else:
            print('Insufficient funds!')


#Create a BankAccount object for a user.
alice_account = BankAccount("Alice")

#Display the initial balance.
alice_account.display_balance()

#Deposit money into the account.
alice_account.deposit(100)

#Display the final balance.
alice_account.display_balance()

#Withdraw money from the account.
alice_account.withdraw(50)

#Display the final balance.
alice_account.display_balance()

#Withdraw money from the account.
alice_account.withdraw(100)

#Display the final balance.
alice_account.display_balance()


