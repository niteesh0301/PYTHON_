from django.urls import path
from .views import post_list, post_detail, add_post, edit_post, delete_post
 
urlpatterns = [
    path('', post_list, name='post_list'),
    path('post/<int:pk>/', post_detail, name='post_detail'),
    path('post/add/', add_post, name='add_post'),
    path('post/edit/<int:pk>/', edit_post, name='edit_post'),
    path('post/delete/<int:pk>/', delete_post, name='delete_post'),
]
