import logging
import unittest
from log_calculator import add, divide
 
# Configure logging
# Set up file handler
file_handler = logging.FileHandler('logfile2.log')
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
 
# Set up logger
logger2 = logging.getLogger('testLogger')
logger2.setLevel(logging.DEBUG)
logger2.addHandler(file_handler)
 
class TestCalculator(unittest.TestCase):
    def test_add(self):
        logger2.info("Testing the add function")
        self.assertEqual(add(3, 4), 7)
 
    def test_divide(self):
        logger2.info("Testing the divide function")
        self.assertEqual(divide(10, 2), 5)
 
if __name__ == "__main__":
    unittest.main()