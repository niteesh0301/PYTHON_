import logging
 
# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='logfile.log',  # Log to a file
    filemode='w'
)
 
def add(a, b):
    logging.debug(f"Adding {a} and {b}")
    return a + b
 
def divide(a, b):
    if b == 0:
        logging.error("Attempt to divide by zero")
        raise ValueError("Cannot divide by zero")
    logging.debug(f"Dividing {a} by {b}")
    return a / b
 
if __name__ == "__main__":
    print(add(10, 5))
    print(divide(10, 2))