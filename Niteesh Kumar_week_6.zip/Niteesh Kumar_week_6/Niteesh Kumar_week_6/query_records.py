import pymysql
from connection import connect_to_database
connection = connect_to_database()


def query_student_records(connection):
    try:
        with connection.cursor() as cursor:
            # SQL statement to select all records from students table
            sql = "SELECT * FROM students"
            # Execute SQL statement to fetch records
            cursor.execute(sql)
            # Fetch all rows
            students = cursor.fetchall()
            # Display student records
            for student in students:
                print(student)
    except pymysql.Error as e:
        print(f"Error querying student records: {e}")

query_student_records(connection)