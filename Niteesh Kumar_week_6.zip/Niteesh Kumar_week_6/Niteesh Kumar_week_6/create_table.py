from connection import connect_to_database

def CreateTable(connection):
    cursor = connection.cursor()
# Drop a table if incase any present with same name
    delete_table = 'drop table if exists students'
# Execute the commands 
        #Create new table
    create_table = """
                CREATE TABLE IF NOT EXISTS students (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100),
                email VARCHAR(100),
                age INT
            )
                """
    # cursor.execute(delete_table)
    # print("Database has been dropped successfully")
    cursor.execute(create_table)
    print('Database is created successfully')

# Test the database connection
connection = connect_to_database()
CreateTable(connection)
if connection:
    connection.close()
    
