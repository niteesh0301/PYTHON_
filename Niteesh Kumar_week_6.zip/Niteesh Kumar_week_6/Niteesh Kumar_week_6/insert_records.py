import pymysql
from connection import connect_to_database
connection = connect_to_database()

def insert_student_records(connection):
    try:
        with connection.cursor() as cursor:
            # Sample student records
            students = [
                (1004, "jack", "john@example.com", 4),
                (1005, "joe", "jsmithj@example.com", 5),
                (1006, "deli", "alice@example.com", 6)
            ]
            # SQL statement to insert records
            sql = "INSERT INTO students (id, name, email, age) VALUES (%s, %s, %s, %s)"
            # Execute SQL statement to insert records
            cursor.executemany(sql, students)
            connection.commit()
            print("Student records inserted successfully!")
    except pymysql.Error as e:
        print(f"Error inserting student records: {e}")

insert_student_records(connection)