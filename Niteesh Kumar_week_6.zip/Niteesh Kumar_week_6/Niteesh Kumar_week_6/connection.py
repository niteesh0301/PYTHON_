import pymysql
# Database Connection 

def connect_to_database():
    try:
       connection =  pymysql.connect(
            host='localhost',
            user='root',
            password='nitish@3P',
            database='students'
            )
       print("Connected to the database successfully!")
       return connection
    except pymysql.Error as e:
        print(f"Error connecting to the database: {e}")
        return None
 

connect_to_database()