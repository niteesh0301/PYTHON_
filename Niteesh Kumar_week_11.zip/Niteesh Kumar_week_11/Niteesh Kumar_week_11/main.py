import tkinter as tk
from tkinter import messagebox


root = tk.Tk()
root.title("Simple Calculator")


display = tk.Entry(root, width=16, font=('Arial', 24), borderwidth=2, relief="solid")
display.grid(row=0, column=0, columnspan=4)


buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+'
]
 
row_val = 1
col_val = 0
 
for button in buttons:
    action = lambda x=button: click_event(x)
    tk.Button(root, text=button, width=5, height=2, command=action).grid(row=row_val, column=col_val)
    col_val += 1
    if col_val > 3:
        col_val = 0
        row_val += 1



def click_event(key):
    if key == '=':
        try:
            result = str(eval(display.get()))
            display.delete(0, tk.END)
            display.insert(tk.END, result)
        except Exception as e:
            messagebox.showerror("Error", "Invalid Input")
    elif key == 'C':
        display.delete(0, tk.END)
    else:
        display.insert(tk.END, key)

tk.Button(root, text='C', width=5, height=2, command=lambda: click_event('C')).grid(row=row_val, column=0)

root.mainloop()